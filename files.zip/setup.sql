-- =============================================
-- 社長コンサルタント協会 診断システム
-- Supabase SQL Editor に貼り付けて実行してください
-- =============================================

-- 診断結果テーブル
CREATE TABLE IF NOT EXISTS shindan_results (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  name text NOT NULL,
  company text,
  income text,
  emp_count text,
  worry text,
  scores jsonb NOT NULL,          -- 各カテゴリのスコア配列
  total_score int NOT NULL,
  max_score int NOT NULL,
  pct int NOT NULL,
  rank text NOT NULL,
  rank_name text NOT NULL,
  consult_name text,              -- 相談申込み時の名前
  consult_email text,             -- 相談申込み時のメール
  consult_tel text,
  consulted boolean DEFAULT false,
  memo text,                      -- 管理者メモ
  status text DEFAULT 'new'       -- new / contacted / done
);

-- 管理者用RLSを無効化（簡易版）
ALTER TABLE shindan_results DISABLE ROW LEVEL SECURITY;

-- インデックス
CREATE INDEX IF NOT EXISTS idx_shindan_created ON shindan_results(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_shindan_status ON shindan_results(status);
